var http = require("http");
var url = require("url");
var fs = require("fs");
var express = require('express');
var validator = require('express-validator');
var path = require('path');
var app = express()
var mysql = require('mysql');
var bodyparser = require('body-parser');
var flash = require('express-flash')
var session = require('express-session');
var cookieParser = require('cookie-parser');
//var axios = require('axios');

app.use(express.static(__dirname + "/views/css"));

app.use(cookieParser());
var db = require('../db/gifInterface');

app.use(session({
	sessionID: 0,
	GifID: 0,
 	secret: 'csci3308',
 	resave: false,
 	saveUninitialized: true,
 	cookie: { maxAge: 60000 }
}))

app.use(flash());
app.use(validator());
app.use(function(err, req, res, next) {
      console.log("Error!")
      res.send("Error!")
    });
app.set('view engine', 'ejs');
app.use(bodyparser.urlencoded({extended: true}))
app.use(bodyparser.json())
app.use(express.static('public'))

//COREY PUT YOUR INFO IN HERE
var connection = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "reallysuperdupersecurepassword",
  database: "gifdb"
});

/*
con.connect(function(err) {
  if (err) throw err;
  con.query("SELECT * FROM table ORDER BY RAND() LIMIT 1", function (err, result, fields) {
    if (err) throw err;
    var gifurl = result[0].url
  });
});
*/

app.get('/', function(req,res,next){	
	db.getGif((url, gifid) => {
		res.render('index.ejs', {gifurl: url, gifid: gifid, musicID:"89D2gmza6o8", st:"0"});
		console.log("Default Main Page");
		req.session.GifID = gifid;
	});
});

app.get('/login', function(req,res,next){
	res.render('login.ejs');
	console.log("Login");
	console.log(req.body);
});

app.get('/create', function(req,res){
	res.render('create.ejs');
	console.log("Create");
});

app.post('/login', function(req,res,next){
	req.assert('email', 'email is required').notEmpty()
	//Validate email
	req.assert('password', 'password is required').notEmpty()
	//Validate password
	var errors = req.validationErrors()
	console.log(errors);
	if( !errors ){
		var item = {
			email: req.sanitize('email').escape().trim(),
			password: req.sanitize('password').escape().trim(),
		}
		var sqlQuery = "SELECT * from users WHERE EMAIL = '" + item.email + "'"; 
		connection.connect(function(err){
			//if(err) throw err; 
			console.log("Connected");
			console.log("Query:" + sqlQuery);
			connection.query(sqlQuery,function(err, result,fields){
				console.log(result[0].password);
				if(result.length > 0){
					if(result[0].password == item.password)
					{
						req.session.sessionID = result[0].UserID;
						console.log(req.session.sessionID);
						console.log("Right Password!");
 			 			req.flash('success', 'Welcome,', item.email);
 			 			res.redirect('/');
					}
					else
					{
						console.log("Wrong Password!");
						req.flash('error', "Wrong email or password.")
						res.redirect('/login');
					}
				}
				else{
					console.log("Wrong Email!");
					req.flash('error', "Wrong email or password.")
					res.redirect('/login');
				}
			});
		});
	}
});

app.post('/create', function(req, res, next){
	req.assert('email', 'email is required').notEmpty()
	req.assert('password', 'password is required').notEmpty()
	req.assert('password1', 'password verification is required').notEmpty()
	var errors = req.validationErrors()
	if( !errors ) { //No errors were found. Passed Validation!
		var item = {
			email: req.sanitize('email').escape().trim(),
 			password: req.sanitize('password').escape().trim(),
 			password1: req.sanitize('password1').escape().trim(),
		}
		if(item.password != item.password1) {
			req.flash('error', 'Passwords are not matching')
			res.redirect('/create')
		}
		else if(item.password == item.password1){
			connection.connect(function(err) {
				connection.query("select * from users where email ='" + item.email + "'" , function(err, rows, fields){
					if (rows.length > 0) {
						req.flash('error', 'That email is already used.')
						res.redirect('/create')

					}
					else{
						connection.query("INSERT INTO users (email, password) VALUES ('"+item.email+"','"+item.password+"')", function(err, result) {
							if (err) {
								console.log(err);
								req.flash('error', err)
								res.redirect('/create')
							} else {
								req.flash('success', 'Account created successfully.')
								res.redirect('/login')

							}
						})
					}
				})
	 		})
		}
	}
 	else { //Display errors to user
 		var error_msg = 'These was an error validating your credentials'
 		errors.forEach(function(error) {
 			error_msg += error.msg + '<br>'
 		})
		req.flash('error', error_msg)
		res.redirect('/create')

	}
});

app.get('/next', function(req,res,next){
	res.redirect('/');
});

app.post('/like', function(req,res,like){
	if (!req.session.sessionID) {
		res.redirect('/login');
	} else {
		connection.connect(function(err) {
			console.log("like connect")
			connection.query("INSERT INTO likes (GifID, UserID) VALUES ('"+req.body.gifid+"','"+req.session.sessionID+"');", function(err, result) {
				if (err) {
					console.log(err)
					req.flash('error', err)
				} else {
					req.flash('success', 'Liked!')
				}
				res.redirect('/')
				/*res.render('create', {
					email: '',
					password: '',
				})*/
			})
		})
	}
});

app.get('/favorites', function(req,res,next){
	if (!req.session.sessionID) {
		res.redirect('/login');
	}
	console.log("getting favorites");
	connection.connect(function(err) {
	var sqlQuery = "Select URL FROM Gifs WHERE GifID in(Select GifID from Likes where UserID = " + req.session.sessionID + ");"
	connection.query(sqlQuery, function(err, result) {
		if(err){
			console.log(err);
			req.flash('error', err)
		}
		else{
			console.log("queried");
			var gifArray = [];
			var arrayLength = result.length;
			for (var i = 0; i < arrayLength; i++) 
			{
			//Call Corey's GID calling fn here
				gifArray.push(result[i].URL)
			//Put variable inside gifArray.push 
			}
			var content = "";
			for (var j = 0; j < gifArray.length; j++){
				content += '<img src =' + gifArray[j] + '></img>'
			}
			res.writeHead(200, {"Content-Type" : "text/html"});
			res.write('<html><head><link rel="stylesheet" href="indexstyle.css" type="text/css"><link rel="stylesheet" href="favorites.css" type="text/css"></head><body><div class="gifs">' + content + '</div><br><div><form action = "/"> <input class=nextbutton type="submit" value="Home""></form></div></body></html>');
			res.end();
			console.log("wrote html");
		}
	});
	});
	});


var server = app.listen(8081, function() {
   var host = server.address().address
   var port = server.address().port  
   console.log("listening at http://%s:%s", host, port)
});
