var gifImgArray = ["1.gif","2.gif","3.gif","4.gif","5.gif","6.gif","7.gif","8.gif","9.gif","10.gif","11.gif","12.gif"];
	var num = Math.floor( Math.random() * 12);
	var musicAr = ["89D2gmza6o8","Z2qLmgnl6Mg","ioULRchLwB0","WEMMVHAINFM","z8cwVLPt82w","kLp_Hh6DKWc","Y9ePLV6VHF0","6ISaCNLcsvM","3K2ly5Ioxf8","rVqAdIMQZlk","_Yv8P19pwlE","gxnvxtYfsd4"];
	var timeAr = ["0","77","35","54","10","55","3","1","0","25","33","19"];