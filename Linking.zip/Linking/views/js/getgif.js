		function getImageGif(imgAr, path) {
			path = path || '../gifs/';
		
			var img = imgAr[num]
			var imgStr = '<img src="'+path+img + ' " height="500" width="600"">'
			document.write(imgStr); document.close()
		}




